<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author hyeonsoft <hyeonsoft@live.co.kr>
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['connectfail']           = '데이터베이스에 연결하는 데 실패했습니다.';
$lang['userexists']            = '죄송하지만 이 계정으로 이미 로그인한 사용자가 있습니다.';
$lang['usernotexists']         = '죄송하지만 해당 사용자가 존재하지 않습니다.';
$lang['writefail']             = '사용자 데이터를 수정할 수 없습니다. 위키 관리자에게 문의하시기 바랍니다';
